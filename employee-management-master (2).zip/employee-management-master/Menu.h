#pragma once
#include <iostream>
#include <conio.h> 


class Menu
{
public:
	Menu();
	int diChuyenPhim();
	~Menu();

private:

};
